/**
 * Authentication module for Emberveil Relay
 * Handles JWT token generation/verification and nonce management
 */

import { createHmac, randomBytes } from 'crypto';
import { config } from './config.js';

// In-memory nonce store (use Redis in production)
const nonceStore = new Map();

/**
 * Generate a cryptographically secure random nonce
 * @returns {string} 64-character hex string (32 bytes)
 */
export function generateNonce() {
  return randomBytes(32).toString('hex');
}

/**
 * Store a nonce for a user with TTL
 * @param {string} username - Lowercase username
 * @param {string} nonce - Nonce value
 * @returns {object} {nonce, expiresAt}
 */
export function storeNonce(username, nonce) {
  const expiresAt = Date.now() + config.nonceTtlMs;
  nonceStore.set(username, { nonce, expiresAt });
  return { nonce, expiresAt };
}

/**
 * Get stored nonce for a user
 * @param {string} username - Lowercase username
 * @returns {object|null} {nonce, expiresAt} or null if not found/expired
 */
export function getNonce(username) {
  const record = nonceStore.get(username);
  if (!record) return null;
  
  if (Date.now() > record.expiresAt) {
    nonceStore.delete(username);
    return null;
  }
  
  return record;
}

/**
 * Delete a nonce (prevent replay attacks)
 * @param {string} username - Lowercase username
 */
export function deleteNonce(username) {
  nonceStore.delete(username);
}

/**
 * Clean up expired nonces (call periodically)
 * @returns {number} number of nonces deleted
 */
export function clearExpiredNonces() {
  const now = Date.now();
  let deleted = 0;
  
  for (const [key, val] of nonceStore) {
    if (val.expiresAt < now) {
      nonceStore.delete(key);
      deleted++;
    }
  }
  
  return deleted;
}

/**
 * Encode data to base64url format (JWT compatible)
 * @param {string|object} input - String or object to encode
 * @returns {string} base64url encoded string
 */
function base64url(input) {
  const str = typeof input === 'string' ? input : JSON.stringify(input);
  return Buffer.from(str).toString('base64url');
}

/**
 * Issue a JWT token for a user
 * @param {object} payload - Token payload
 * @returns {string} JWT token
 */
export function issueJWT(payload) {
  const header = base64url({ alg: 'HS256', typ: 'JWT' });
  const body = base64url({ 
    ...payload, 
    iat: Math.floor(Date.now() / 1000)
  });
  const sig = createHmac('sha256', config.jwtSecret)
    .update(`${header}.${body}`)
    .digest('base64url');
  
  return `${header}.${body}.${sig}`;
}

/**
 * Verify and decode a JWT token
 * @param {string} token - JWT token to verify
 * @returns {object|null} decoded payload or null if invalid/expired
 */
export function verifyJWT(token) {
  try {
    const [header, body, sig] = token.split('.');
    if (!header || !body || !sig) return null;
    
    const expected = createHmac('sha256', config.jwtSecret)
      .update(`${header}.${body}`)
      .digest('base64url');
    
    if (sig !== expected) return null;
    
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString());
    
    // Check expiration
    if (payload.exp && payload.exp < Math.floor(Date.now() / 1000)) {
      return null;
    }
    
    return payload;
  } catch {
    return null;
  }
}

/**
 * Start nonce cleanup interval (every 60 seconds)
 * @returns {NodeJS.Timer} interval ID for cleanup
 */
export function startNonceCleanupInterval() {
  return setInterval(() => {
    const deleted = clearExpiredNonces();
    if (deleted > 0) {
      console.log(`🧹 Cleaned up ${deleted} expired nonces`);
    }
  }, config.NonceCleanupIntervalMs);
}
