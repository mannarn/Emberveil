/**
 * Authentication routes for Emberveil Relay
 * User registration, login, and signature verification
 */

import { Router } from 'express';
import { ethers } from 'ethers';
import { ed25519 } from '@noble/curves/ed25519';
import { getContract, getSigner, getProvider, isBlockchainReady } from '../blockchain.js';
import { 
  generateNonce, 
  storeNonce, 
  getNonce, 
  deleteNonce, 
  issueJWT 
} from '../auth.js';
import {
  validateUsername,
  validateEd25519PublicKey,
  validatePasswordDoubleHash,
  validateDidDocument,
  validateSignature,
  normalizeUsername,
  formatSuccess,
  formatError
} from '../utils/validation.js';

const router = Router();

/**
 * POST /register
 * Register a new user with public key and DID document
 */
router.post('/register', async (req, res) => {
  try {
    const { username, didDocument, ed25519PublicKey, passwordDoubleHash } = req.body;
    
    // Validate input
    if (!username || !didDocument || !ed25519PublicKey || !passwordDoubleHash) {
      return res.status(400).json(formatError('Missing required fields'));
    }
    
    // Normalize username
    const normalizedUsername = normalizeUsername(username);
    
    // Validate fields
    const usernameCheck = validateUsername(normalizedUsername);
    if (!usernameCheck.valid) {
      return res.status(400).json(formatError(usernameCheck.error));
    }
    
    const didCheck = validateDidDocument(didDocument);
    if (!didCheck.valid) {
      return res.status(400).json(formatError(didCheck.error));
    }
    
    const keyCheck = validateEd25519PublicKey(ed25519PublicKey);
    if (!keyCheck.valid) {
      return res.status(400).json(formatError(keyCheck.error));
    }
    
    const hashCheck = validatePasswordDoubleHash(passwordDoubleHash);
    if (!hashCheck.valid) {
      return res.status(400).json(formatError(hashCheck.error));
    }
    
    if (!isBlockchainReady()) {
      return res.status(503).json(formatError('Blockchain not ready'));
    }
    
    const contract = getContract();
    const provider = getProvider();
    
    // Check username availability
    const available = await contract.isUsernameAvailable(normalizedUsername);
    if (!available) {
      return res.status(409).json(formatError('Username already taken'));
    }
    
    // Estimate gas
    console.log(`⛽ Estimating gas for ${normalizedUsername}...`);
    const estimatedGas = await contract.registerUser.estimateGas(
      normalizedUsername,
      didDocument,
      ed25519PublicKey,
      passwordDoubleHash
    );
    
    // Add 20% buffer
    const gasLimit = (BigInt(estimatedGas) * BigInt(120)) / BigInt(100);
    const feeData = await provider.getFeeData();
    const totalCost = gasLimit * feeData.gasPrice;
    
    const signer = getSigner();
    const balance = await provider.getBalance(signer.address);
    
    if (balance < totalCost) {
      return res.status(503).json(formatError(
        'Relay wallet has insufficient funds',
        {
          needed: ethers.formatEther(totalCost),
          available: ethers.formatEther(balance)
        }
      ));
    }
    
    // Execute registration
    console.log(`📝 Registering user: ${normalizedUsername}`);
    const tx = await contract.registerUser(
      normalizedUsername,
      didDocument,
      ed25519PublicKey,
      passwordDoubleHash,
      { gasLimit }
    );
    
    const receipt = await tx.wait();
    console.log(`✓ Registered ${normalizedUsername} → tx ${receipt.hash}`);
    
    res.status(201).json(formatSuccess({
      username: normalizedUsername,
      txHash: receipt.hash,
      blockNumber: receipt.blockNumber,
      message: 'User registered successfully'
    }));
  } catch (err) {
    console.error('POST /register failed:', err.message);
    if (err.message.includes('User does not exist')) {
      return res.status(404).json(formatError('Username not found on chain'));
    }
    res.status(500).json(formatError(
      err.message.includes('insufficient') 
        ? 'Relay wallet has insufficient funds' 
        : 'Registration failed'
    ));
  }
});

/**
 * POST /request-nonce
 * Generate and return a nonce for user authentication
 */
router.post('/request-nonce', async (req, res) => {
  try {
    const { username } = req.body;
    
    if (!username || typeof username !== 'string') {
      return res.status(400).json(formatError('Username required'));
    }
    
    const normalizedUsername = normalizeUsername(username);
    
    const usernameCheck = validateUsername(normalizedUsername);
    if (!usernameCheck.valid) {
      return res.status(400).json(formatError(usernameCheck.error));
    }
    
    if (!isBlockchainReady()) {
      return res.status(503).json(formatError('Blockchain not ready'));
    }
    
    const contract = getContract();
    
    // Verify user exists
    const exists = await contract.registeredUsernames(normalizedUsername);
    if (!exists) {
      return res.status(404).json(formatError('User not found'));
    }
    
    // Verify user is active
    const isActive = await contract.isUserActive(normalizedUsername);
    if (!isActive) {
      return res.status(403).json(formatError('Account is deactivated'));
    }
    
    // Generate nonce
    const nonce = generateNonce();
    storeNonce(normalizedUsername, nonce);
    
    console.log(`🔑 Nonce issued for ${normalizedUsername}`);
    
    res.json(formatSuccess({
      nonce,
      expiresIn: 300, // 5 minutes in seconds
      algorithm: 'Ed25519'
    }));
  } catch (err) {
    console.error('POST /request-nonce failed:', err.message);
    res.status(500).json(formatError('Failed to generate nonce'));
  }
});

/**
 * POST /verify-signature
 * Verify user's Ed25519 signature and issue JWT token
 */
router.post('/verify-signature', async (req, res) => {
  try {
    const { username, signature } = req.body;
    
    if (!username || !signature) {
      return res.status(400).json(formatError('Username and signature required'));
    }
    
    const normalizedUsername = normalizeUsername(username);
    
    // Validate signature format
    const sigCheck = validateSignature(signature);
    if (!sigCheck.valid) {
      return res.status(400).json(formatError(sigCheck.error));
    }
    
    // Get stored nonce
    const record = getNonce(normalizedUsername);
    if (!record) {
      return res.status(400).json(formatError(
        'No valid nonce found. Please request a new one at /request-nonce'
      ));
    }
    
    if (!isBlockchainReady()) {
      return res.status(503).json(formatError('Blockchain not ready'));
    }
    
    const contract = getContract();
    
    // Fetch public key from chain
    let pubKeyHex;
    try {
      pubKeyHex = await contract.getEd25519PublicKey(normalizedUsername);
    } catch {
      deleteNonce(normalizedUsername);
      return res.status(404).json(formatError('Public key not found on chain'));
    }
    
    // Verify signature
    const pubKeyBytes = Uint8Array.from(Buffer.from(pubKeyHex, 'hex'));
    const sigBytes = Uint8Array.from(Buffer.from(signature, 'hex'));
    const messageBytes = new TextEncoder().encode(record.nonce);
    
    let isValid = false;
    try {
      isValid = ed25519.verify(sigBytes, messageBytes, pubKeyBytes);
    } catch {
      isValid = false;
    }
    
    // Consume nonce (prevents replay attacks)
    deleteNonce(normalizedUsername);
    
    if (!isValid) {
      console.log(`✗ Signature verification failed for ${normalizedUsername}`);
      return res.status(401).json(formatError('Invalid signature. Wrong password or corrupted data'));
    }
    
    // Issue JWT
    const token = issueJWT({
      username: normalizedUsername,
      iat: Math.floor(Date.now() / 1000),
      exp: Math.floor(Date.now() / 1000) + (24 * 60 * 60) // 24 hours
    });
    
    console.log(`✓ Signed in: ${normalizedUsername}`);
    
    res.json(formatSuccess({
      token,
      username: normalizedUsername,
      expiresIn: 86400, // 24 hours in seconds
      tokenType: 'Bearer'
    }));
  } catch (err) {
    console.error('POST /verify-signature failed:', err.message);
    res.status(500).json(formatError('Signature verification failed'));
  }
});

export default router;
