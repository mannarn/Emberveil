/**
 * Health and utility routes for Emberveil Relay
 */

import { Router } from 'express';
import { ethers } from 'ethers';
import { getContract, getSigner, getProvider, isBlockchainReady } from '../blockchain.js';
import { formatSuccess, formatError } from '../utils/validation.js';

const router = Router();

/**
 * GET /health
 * Check if relay is running and ready
 */
router.get('/health', (req, res) => {
  res.json(formatSuccess({
    status: 'ok',
    ready: isBlockchainReady(),
    relayWallet: getSigner()?.address || null,
    contractAddress: getContract()?.address || null,
    network: 'Polygon Amoy',
    timestamp: new Date().toISOString()
  }));
});

/**
 * GET /wallet-info
 * Get relay wallet balance and address
 */
router.get('/wallet-info', async (req, res) => {
  try {
    if (!isBlockchainReady()) {
      return res.status(503).json(formatError('Blockchain not ready'));
    }
    
    const signer = getSigner();
    const provider = getProvider();
    const balance = await provider.getBalance(signer.address);
    
    res.json(formatSuccess({
      address: signer.address,
      balance: ethers.formatEther(balance),
      balanceWei: balance.toString()
    }));
  } catch (err) {
    console.error('GET /wallet-info failed:', err.message);
    res.status(500).json(formatError('Failed to fetch wallet info'));
  }
});

/**
 * GET /version
 * Get relay version and implementation details
 */
router.get('/version', (req, res) => {
  res.json(formatSuccess({
    name: 'emberveil-relay',
    version: '2.0.0',
    protocol: 'Ed25519 Challenge-Response',
    blockchain: 'Polygon Amoy',
    tokenScheme: 'JWT HS256'
  }));
});

export default router;
