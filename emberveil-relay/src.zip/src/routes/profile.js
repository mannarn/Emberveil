/**
 * User profile routes for Emberveil Relay
 * Requires authentication
 */

import { Router } from 'express';
import { getContract, isBlockchainReady } from '../blockchain.js';
import { requireAuth } from '../middleware.js';
import { normalizeUsername, formatSuccess, formatError } from '../utils/validation.js';

const router = Router();

// All routes require authentication
router.use(requireAuth);

/**
 * GET /profile/:username
 * Get user profile (authenticated users only)
 */
router.get('/profile/:username', async (req, res) => {
  try {
    const normalizedUsername = normalizeUsername(req.params.username);
    
    // Users can only access their own profile
    if (req.user.username !== normalizedUsername) {
      return res.status(403).json(formatError('Forbidden: Cannot access other users\' profiles'));
    }
    
    if (!isBlockchainReady()) {
      return res.status(503).json(formatError('Blockchain not ready'));
    }
    
    const contract = getContract();
    const profile = await contract.getUserProfile(normalizedUsername);
    
    res.json(formatSuccess({
      username: normalizedUsername,
      didDocument: profile.didEmberveilDocument,
      metadataCID: profile.metadataCID,
      isActive: profile.isActive,
      registrationTime: Number(profile.registrationTime),
      registeredAt: new Date(Number(profile.registrationTime) * 1000).toISOString()
    }));
  } catch (err) {
    console.error('GET /profile/:username failed:', err.message);
    if (err.message.includes('User does not exist')) {
      return res.status(404).json(formatError('User profile not found'));
    }
    res.status(500).json(formatError('Failed to fetch profile'));
  }
});

/**
 * GET /me
 * Get authenticated user's own profile
 */
router.get('/me', async (req, res) => {
  try {
    if (!isBlockchainReady()) {
      return res.status(503).json(formatError('Blockchain not ready'));
    }
    
    const contract = getContract();
    const username = req.user.username;
    const profile = await contract.getUserProfile(username);
    
    res.json(formatSuccess({
      username,
      didDocument: profile.didEmberveilDocument,
      metadataCID: profile.metadataCID,
      isActive: profile.isActive,
      registrationTime: Number(profile.registrationTime),
      registeredAt: new Date(Number(profile.registrationTime) * 1000).toISOString()
    }));
  } catch (err) {
    console.error('GET /me failed:', err.message);
    res.status(500).json(formatError('Failed to fetch profile'));
  }
});

/**
 * GET /public/:username
 * Get public information about a user (no auth required for future use)
 * Currently just returns if user exists
 */
router.get('/public/:username', async (req, res) => {
  try {
    const normalizedUsername = normalizeUsername(req.params.username);
    
    if (!isBlockchainReady()) {
      return res.status(503).json(formatError('Blockchain not ready'));
    }
    
    const contract = getContract();
    const exists = await contract.registeredUsernames(normalizedUsername);
    
    if (!exists) {
      return res.status(404).json(formatError('User not found'));
    }
    
    res.json(formatSuccess({
      username: normalizedUsername,
      exists: true
    }));
  } catch (err) {
    console.error('GET /public/:username failed:', err.message);
    res.status(500).json(formatError('Failed to check user'));
  }
});

export default router;
