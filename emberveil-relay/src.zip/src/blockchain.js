/**
 * Blockchain module for Emberveil Relay
 * Handles ethers.js provider, wallet, and contract initialization
 */

import { ethers } from 'ethers';
import { config } from './config.js';

// Contract ABI (minimal, only functions relay calls)
const CONTRACT_ABI = [
  'function isUsernameAvailable(string calldata username) external view returns (bool)',
  'function registeredUsernames(string calldata username) external view returns (bool)',
  'function isUserActive(string calldata username) external view returns (bool)',
  'function registerUser(string calldata username, string calldata didDocument, string calldata ed25519PublicKey, bytes32 passwordDoubleHash) external',
  'function getEd25519PublicKey(string calldata username) external view returns (string)',
  'function getUserProfile(string calldata username) external view returns (tuple(string didEmberveilDocument, string metadataCID, bool isActive, uint256 registrationTime))'
];

let provider;
let signer;
let contract;

/**
 * Initialize blockchain provider, signer, and contract instance
 * @throws {Error} if initialization fails
 */
export async function initializeBlockchain() {
  try {
    provider = new ethers.JsonRpcProvider(config.rpcUrl);
    signer = new ethers.Wallet(config.relayPrivateKey, provider);
    contract = new ethers.Contract(config.contractAddress, CONTRACT_ABI, signer);
    
    console.log(`⛓  Contract Address: ${config.contractAddress}`);
    console.log(`👛 Relay Wallet: ${signer.address}`);
    
    // Verify connection
    const network = await provider.getNetwork();
    console.log(`🌐 Network: ${network.name} (ChainID: ${network.chainId})`);
    
    // Check wallet balance
    const balance = await provider.getBalance(signer.address);
    console.log(`💰 Balance: ${ethers.formatEther(balance)} ETH`);
    
    return { provider, signer, contract };
  } catch (err) {
    console.error('❌ Blockchain initialization failed:', err.message);
    throw err;
  }
}

/**
 * Get the initialized contract instance
 * @returns {ethers.Contract|null} contract instance or null if not initialized
 */
export function getContract() {
  return contract;
}

/**
 * Get the signer instance
 * @returns {ethers.Wallet|null} signer instance or null if not initialized
 */
export function getSigner() {
  return signer;
}

/**
 * Get the provider instance
 * @returns {ethers.JsonRpcProvider|null} provider instance or null if not initialized
 */
export function getProvider() {
  return provider;
}

/**
 * Check if blockchain is ready
 * @returns {boolean} true if contract, signer, and provider are initialized
 */
export function isBlockchainReady() {
  return !!(contract && signer && provider);
}
