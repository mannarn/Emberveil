/**
 * Middleware for Emberveil Relay
 * Authentication, error handling, logging
 */

import { verifyJWT } from '../auth.js';
import { formatError } from '../utils/validation.js';

/**
 * Middleware: Require authentication via JWT Bearer token
 * Attaches decoded user to req.user
 */
export function requireAuth(req, res, next) {
  const authHeader = req.headers.authorization;
  
  if (!authHeader?.startsWith('Bearer ')) {
    return res.status(401).json(formatError('Missing or invalid Authorization header'));
  }
  
  const token = authHeader.slice(7);
  const payload = verifyJWT(token);
  
  if (!payload) {
    return res.status(401).json(formatError('Invalid or expired token'));
  }
  
  req.user = payload;
  next();
}

/**
 * Middleware: Log incoming requests
 */
export function logRequest(req, res, next) {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] ${req.method} ${req.path}`);
  next();
}

/**
 * Middleware: Global error handler (must be last)
 */
export function errorHandler(err, req, res, _next) {
  console.error('Unhandled error:', err.message);
  
  res.status(err.status || 500).json(
    formatError(err.message || 'Internal server error')
  );
}

/**
 * Middleware: CORS configuration
 */
export function corsOptions(req, res, next) {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  
  next();
}
