/**
 * Configuration module for Emberveil Relay
 * Exports all environment-based configuration
 */

import dotenv from 'dotenv';

dotenv.config();

export const config = {
  // Blockchain
  contractAddress: process.env.CONTRACT_ADDRESS,
  rpcUrl: process.env.RPC_URL || 'https://rpc-amoy.polygon.technology',
  relayPrivateKey: process.env.RELAY_PRIVATE_KEY,
  
  // Security
  jwtSecret: process.env.JWT_SECRET || 'default-secret-change-in-production',
  
  // Server
  port: process.env.PORT || 8080,
  nodeEnv: process.env.NODE_ENV || 'development',
  
  // Nonce
  nonceTtlMs: 5 * 60 * 1000, // 5 minutes
  NonceCleanupIntervalMs: 60_000, // 60 seconds
  
  // Validation
  usernameMinLength: 2,
  usernameMaxLength: 32,
  Ed25519KeyLength: 64, // hex chars for 32 bytes
  PasswordHashLength: 66, // 0x + 64 hex chars
};

/**
 * Validate required environment variables
 * @throws {Error} if required config is missing
 */
export function validateConfig() {
  if (!config.relayPrivateKey) {
    throw new Error('RELAY_PRIVATE_KEY required in .env');
  }
  if (!config.contractAddress) {
    throw new Error('CONTRACT_ADDRESS required in .env');
  }
  if (!config.jwtSecret || config.jwtSecret === 'default-secret-change-in-production') {
    console.warn('⚠️  JWT_SECRET not set or using default — set JWT_SECRET in production!');
  }
}
