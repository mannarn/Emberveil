/**
 * Utility functions for Emberveil Relay
 * Validation, formatting, and helper functions
 */

import { config } from '../config.js';

/**
 * Validate username format
 * @param {string} username - Username to validate
 * @returns {object} {valid: boolean, error?: string}
 */
export function validateUsername(username) {
  if (!username || typeof username !== 'string') {
    return { valid: false, error: 'Username must be a string' };
  }
  
  const len = username.length;
  if (len < config.usernameMinLength || len > config.usernameMaxLength) {
    return { 
      valid: false, 
      error: `Username must be ${config.usernameMinLength}-${config.usernameMaxLength} characters` 
    };
  }
  
  if (!/^[a-z0-9_-]+$/i.test(username)) {
    return { 
      valid: false, 
      error: 'Username can only contain letters, numbers, underscores, and hyphens' 
    };
  }
  
  return { valid: true };
}

/**
 * Validate Ed25519 public key format
 * @param {string} pubKey - Public key hex string
 * @returns {object} {valid: boolean, error?: string}
 */
export function validateEd25519PublicKey(pubKey) {
  if (!pubKey || typeof pubKey !== 'string') {
    return { valid: false, error: 'Public key must be a string' };
  }
  
  if (pubKey.length !== config.Ed25519KeyLength) {
    return { 
      valid: false, 
      error: `Ed25519 public key must be exactly ${config.Ed25519KeyLength} hex characters (32 bytes)` 
    };
  }
  
  if (!/^[0-9a-fA-F]+$/.test(pubKey)) {
    return { 
      valid: false, 
      error: 'Public key must be valid hexadecimal' 
    };
  }
  
  return { valid: true };
}

/**
 * Validate password double hash format
 * @param {string} hash - Password hash string
 * @returns {object} {valid: boolean, error?: string}
 */
export function validatePasswordDoubleHash(hash) {
  if (!hash || typeof hash !== 'string') {
    return { valid: false, error: 'Password hash must be a string' };
  }
  
  if (!hash.startsWith('0x')) {
    return { valid: false, error: 'Password hash must start with "0x"' };
  }
  
  if (hash.length !== config.PasswordHashLength) {
    return { 
      valid: false, 
      error: `Password hash must be exactly ${config.PasswordHashLength} characters (0x + 64 hex)` 
    };
  }
  
  if (!/^0x[0-9a-fA-F]+$/.test(hash)) {
    return { 
      valid: false, 
      error: 'Password hash must be valid hexadecimal' 
    };
  }
  
  return { valid: true };
}

/**
 * Validate Ed25519 signature format
 * @param {string} signature - Signature hex string
 * @returns {object} {valid: boolean, error?: string}
 */
export function validateSignature(signature) {
  if (!signature || typeof signature !== 'string') {
    return { valid: false, error: 'Signature must be a string' };
  }
  
  // Ed25519 signature = 64 bytes = 128 hex characters
  if (signature.length !== 128) {
    return { 
      valid: false, 
      error: 'Signature must be exactly 128 hex characters (64 bytes)' 
    };
  }
  
  if (!/^[0-9a-fA-F]+$/.test(signature)) {
    return { 
      valid: false, 
      error: 'Signature must be valid hexadecimal' 
    };
  }
  
  return { valid: true };
}

/**
 * Validate DID document
 * @param {string} did - DID document string
 * @returns {object} {valid: boolean, error?: string}
 */
export function validateDidDocument(did) {
  if (!did || typeof did !== 'string') {
    return { valid: false, error: 'DID document must be a string' };
  }
  
  if (did.trim().length === 0) {
    return { valid: false, error: 'DID document cannot be empty' };
  }
  
  return { valid: true };
}

/**
 * Normalize username to lowercase
 * @param {string} username - Username to normalize
 * @returns {string} lowercase username
 */
export function normalizeUsername(username) {
  return username.toLowerCase().trim();
}

/**
 * Format error response
 * @param {string} message - Error message
 * @param {object} details - Additional error details
 * @returns {object} formatted error object
 */
export function formatError(message, details = {}) {
  return {
    success: false,
    error: message,
    ...details
  };
}

/**
 * Format success response
 * @param {object} data - Response data
 * @returns {object} formatted success object
 */
export function formatSuccess(data = {}) {
  return {
    success: true,
    ...data
  };
}
