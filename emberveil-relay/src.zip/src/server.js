/**
 * Emberveil Relay Server
 * Self-Sovereign Identity Authentication Relay
 * 
 * Main entry point - Express server with modular architecture
 */

import express from 'express';
import cors from 'cors';
import { config, validateConfig } from './config.js';
import { initializeBlockchain } from './blockchain.js';
import { startNonceCleanupInterval } from './auth.js';
import { logRequest, errorHandler } from './middleware.js';

// Import route handlers
import healthRoutes from './routes/health.js';
import authRoutes from './routes/auth.js';
import profileRoutes from './routes/profile.js';

// Create Express app
const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(logRequest);

// Routes
app.use('/api', healthRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/user', profileRoutes);

// Legacy route aliases (for backward compatibility)
app.post('/api/check-username', async (req, res) => {
  try {
    const { username } = req.body;
    const contract = require('./blockchain.js').getContract();
    const available = await contract.isUsernameAvailable(username.toLowerCase());
    res.json({ success: true, available, username: username.toLowerCase() });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/register-user', async (req, res) => {
  // Redirect to new route
  res.status(301).json({ 
    message: 'Moved. Use POST /api/auth/register instead',
    newEndpoint: '/api/auth/register'
  });
});

// Root route
app.get('/', (req, res) => {
  res.json({
    name: 'Emberveil Relay Server',
    version: '2.0.0',
    status: 'running',
    endpoints: {
      health: '/api/health',
      authentication: '/api/auth/register, /api/auth/request-nonce, /api/auth/verify-signature',
      profile: '/api/user/me, /api/user/profile/:username'
    }
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    success: false,
    error: 'Route not found',
    path: req.path
  });
});

// Global error handler (must be last)
app.use(errorHandler);

/**
 * Start the server
 */
async function startServer() {
  try {
    // Validate configuration
    console.log('🔍 Validating configuration...');
    validateConfig();
    
    // Initialize blockchain
    console.log('⛓  Initializing blockchain...');
    await initializeBlockchain();
    
    // Start nonce cleanup interval
    startNonceCleanupInterval();
    
    // Start Express server
    const server = app.listen(config.port, () => {
      console.log(`
╔════════════════════════════════════════════╗
║     ✓ Emberveil Relay Server Running       ║
╠════════════════════════════════════════════╣
║ Port:        ${String(config.port).padEnd(28)}║
║ Environment: ${String(config.nodeEnv).padEnd(28)}║
║ Network:     Polygon Amoy (Testnet)        ║
╚════════════════════════════════════════════╝
      `);
      
      console.log('📋 Available Endpoints:');
      console.log('  GET  /api/health              - Server health check');
      console.log('  GET  /api/wallet-info         - Relay wallet info');
      console.log('  GET  /api/version             - Version info');
      console.log('  POST /api/auth/register       - Register new user');
      console.log('  POST /api/auth/request-nonce  - Get nonce for login');
      console.log('  POST /api/auth/verify-signature - Verify signature & login');
      console.log('  GET  /api/user/me             - Get authenticated user profile');
      console.log('  GET  /api/user/profile/:username - Get user profile (authenticated)');
      console.log('  GET  /api/user/public/:username  - Check if user exists');
      console.log('');
    });
    
    // Graceful shutdown
    process.on('SIGTERM', () => {
      console.log('📴 Shutting down gracefully...');
      server.close(() => {
        console.log('✓ Server shut down');
        process.exit(0);
      });
    });
  } catch (err) {
    console.error('❌ Failed to start server:', err.message);
    console.error(err);
    process.exit(1);
  }
}

// Start the server
startServer();

export default app;
